#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	float h, k, BMI;
	printf("�п�J����(m)�B�魫(kg)\n");
	scanf_s("%f %f", &h, &k);

	BMI = k / (h*h);
	printf("BMI=%f\n", BMI);
	if (BMI < 18.5)
	{
		printf("underweight");
	}
	else if (18.5 <= BMI && BMI < 24.9)
	{
		printf("normal\n");
	}
	else if(25 <= BMI && BMI<29.9)
	{
		printf("overweight\n");
	}
	else
	{
		printf("obese\n");
	}

	system("pause");
	return 0;
}