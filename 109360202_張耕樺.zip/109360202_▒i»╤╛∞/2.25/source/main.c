#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	printf("ZZZ     Z\n");
	printf("Z ZZ    Z\n");
	printf("Z  ZZ   Z\n");
	printf("Z    ZZ Z\n");
	printf("Z     ZZZ\n");
	printf("         \n");
	printf("   GGG   \n");
	printf(" G     G \n");
	printf("G   G   G\n");
	printf("G   G   G\n");
	printf(" GGGG    \n");
	printf("         \n");
	printf("HHHHHHHHH\n");
	printf("   HH    \n");
	printf("   HH    \n");
	printf("   HH    \n");
	printf("HHHHHHHHH\n");
	system("pause");
	return 0;
}