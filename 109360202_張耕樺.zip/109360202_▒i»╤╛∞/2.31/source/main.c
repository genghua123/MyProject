#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int a = 0, b = 1, c = 2, d = 3, e = 4, f = 5, g = 6, h = 7, i = 8, j = 9, k = 10;
	printf("number\tsquare\tcube\n");
	printf("%d\t%d\t%d\n", a, a*a, a*a*a);
	printf("%d\t%d\t%d\n", b, b*b, b*b*b);
	printf("%d\t%d\t%d\n", c, c*c, c*c*c);
	printf("%d\t%d\t%d\n", d, d*d, d*d*d);
	printf("%d\t%d\t%d\n", e, e*e, e*e*e);
	printf("%d\t%d\t%d\n", f, f*f, f*f*f);
	printf("%d\t%d\t%d\n", g, g*g, g*g*g);
	printf("%d\t%d\t%d\n", h, h*h, h*h*h);
	printf("%d\t%d\t%d\n", i, i*i, i*i*i);
	printf("%d\t%d\t%d\n", j, j*j, j*j*j);
	printf("%d\t%d\t%d\n", k, k*k, k*k*k);
	system("pause");
	return 0;
}